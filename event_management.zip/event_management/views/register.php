<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Pengguna</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div class="container mt-4">
        <h1>Registrasi Pengguna</h1>

        <!-- Tempat untuk menampilkan pesan response -->
        <div id="responseMessage"></div>

        <form id="registerForm" method="POST">
            <div class="form-group">
                <input type="text" class="form-control" id="name" name="name" placeholder="Nama Lengkap" required>
            </div>
            <div class="form-group">
                <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="password" class="form-control" id="password" name="password" placeholder="Kata Sandi (Minimal 8 karakter)" required>
            </div>
            <button type="submit" class="btn btn-primary">Daftar</button>
        </form>

        <script>
            $(document).ready(function() {
                $('#registerForm').on('submit', function(e) {
                    e.preventDefault(); // Mencegah reload halaman

                    var name = $('#name').val();
                    var email = $('#email').val();
                    var password = $('#password').val();

                    // Kirim data ke API menggunakan AJAX
                    $.ajax({
                        url: 'http://localhost/event_management/api/register_api.php',  // Pastikan URL API benar
                        type: 'POST',
                        data: {
                            name: name,
                            email: email,
                            password: password
                        },
                        success: function(response) {
                            var data = JSON.parse(response);
                            if (data.status === 'success') {
                                $('#responseMessage').html('<div class="alert alert-success">' + data.message + '</div>');
                            } else {
                                $('#responseMessage').html('<div class="alert alert-danger">' + data.message + '</div>');
                            }
                        },
                        error: function() {
                            $('#responseMessage').html('<div class="alert alert-danger">Terjadi kesalahan. Silakan coba lagi.</div>');
                        }
                    });
                });
            });
        </script>
    </div>
</body>
</html>

