<?php
// Ambil semua event melalui API
$apiUrl = "https://example.com/api/event"; // Ganti URL API
$response = file_get_contents($apiUrl);
$events = json_decode($response, true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event List</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Daftar Event</h1>
        <div class="row">
            <?php foreach ($events as $event): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($event['title']); ?></h5>
                            <p class="card-text">
                                <?= htmlspecialchars($event['date']); ?><br>
                                <?= htmlspecialchars($event['location']); ?>
                            </p>
                            <a href="event_detail.php?id=<?= $event['id']; ?>" class="btn btn-primary">
                                Lihat Detail
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
