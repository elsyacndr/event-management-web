<footer class="bg-dark text-white py-4">
    <div class="container">
        <div class="row">
            <!-- Logo Section -->
            <div class="col-md-4">
                <h3>Welcome to EventHub</h3>
                <p>Your premier digital ticket management system designed to bridge the gap between event enthusiasts and organizers.</p>
            </div>
            
            <!-- Links Section -->
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white">Terms & Conditions</a></li>
                    <li><a href="#" class="text-white">About Us</a></li>
                    <li><a href="#" class="text-white">Organizers</a></li>
                    <li><a href="#" class="text-white">Contact Us</a></li>
                </ul>
            </div>
            
            <!-- Contact Section -->
            <div class="col-md-4">
                <h5>Contact Information</h5>
                <p>Jl. Pucang Asri V No.3, Kertajaya, Kec. Gubeng, Surabaya, Jawa Timur 60282</p>
                <p>Email: <a href="mailto:info@bozztech.id" class="text-white">info@bozztech.id</a></p>
                <p>Phone: <a href="tel:+6282336441318" class="text-white">+6282336441318</a></p>
            </div>
        </div>
    </div>

    <!-- Footer Bottom -->
    <div class="footer-bottom bg-dark text-center py-2">
        <p class="mb-0">&copy; 2024 PT Ekis Muda Berkarya. All Rights Reserved.</p>
    </div>
</footer>
