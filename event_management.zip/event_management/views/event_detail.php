<?php include 'header.php'; ?>
<?php
// Ambil semua event melalui API
$apiUrl = "https://example.com/api/event"; // Ganti URL API
$response = file_get_contents($apiUrl);
$events = json_decode($response, true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event List</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Daftar Event</h1>
        <div class="row">
            <?php foreach ($events as $event): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($event['title']); ?></h5>
                            <p class="card-text">
                                <?= htmlspecialchars($event['date']); ?><br>
                                <?= htmlspecialchars($event['location']); ?>
                            </p>
                            <a href="event_detail.php?id=<?= $event['id']; ?>" class="btn btn-primary">
                                Lihat Detail
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

<section class="event-detail">
    <h1 id="eventName">Loading...</h1>
    <p id="eventStatus"></p>
    <p id="eventDate"></p>
    <p id="eventLocation"></p>
    <p id="eventDescription"></p>
    <button class="share-event">Bagikan Event</button>
    <p id="eventStatusMessage"></p>

    <div class="organizer-info">
        <p id="eventOrganizer"></p>
        <a href="#" id="eventProfileLink">Lihat Profile</a>
    </div>

    <div class="ticket">
        <p id="totalPrice">Total Harga: 0</p>
        <button class="buy-ticket">Pesan Sekarang</button>
    </div>
</section>

<script>
    // Mendapatkan ID acara dari URL
    const urlParams = new URLSearchParams(window.location.search);
    const eventId = urlParams.get('id');

    // Mengambil data event dari API
    if (eventId) {
        $.ajax({
            url: 'api/EventApiController.php?id=' + eventId,
            method: 'GET',
            success: function(response) {
                const event = JSON.parse(response);
                
                // Jika acara ditemukan
                if (event.name) {
                    $('#eventName').text(event.name);
                    $('#eventStatus').text(event.status);
                    $('#eventDate').text(event.date);
                    $('#eventLocation').text(event.location);
                    $('#eventDescription').text(event.description);
                    $('#eventOrganizer').text('Organised By: ' + event.organizer);
                    $('#eventProfileLink').attr('href', 'organizer-profile.php?id=' + event.organizerId);
                    $('#totalPrice').text('Total Harga: ' + event.price);
                    $('#eventStatusMessage').text(event.status === 'Over' ? 'The Event is Over' : 'Event is Upcoming');
                } else {
                    $('#eventName').text('Event not found');
                }
            },
            error: function() {
                alert('Error retrieving event data');
            }
        });
    }
</script>
<?php include 'footer.php'; ?>










<?php include 'header.php'; ?>
<?php
// Ambil ID event dari URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fungsi untuk mengambil data dari API
function getEventData($url) {
    $response = file_get_contents($url);
    return json_decode($response, true);
}

if ($id > 0) {
    // Jika ID ada, tampilkan detail event
    $apiUrl = "https://example.com/api/event/" . $id; // Ganti URL API
    $event = getEventData($apiUrl);
} else {
    // Jika ID tidak ada, tampilkan semua event
    $apiUrl = "https://example.com/api/event"; // Ganti URL API
    $events = getEventData($apiUrl);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $id > 0 ? htmlspecialchars($event['title']) : 'Daftar Event'; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <?php if ($id > 0 && isset($event['id'])): ?>
            <!-- Tampilkan Detail Event -->
            <h1><?= htmlspecialchars($event['title']); ?></h1>
            <p>Status: <?= htmlspecialchars($event['status']); ?></p>
            <p>Tanggal: <?= htmlspecialchars($event['date']); ?></p>
            <p>Lokasi: <?= htmlspecialchars($event['location']); ?></p>
            <p>Deskripsi: <?= htmlspecialchars($event['description']); ?></p>
            <p>Organized By: <?= htmlspecialchars($event['organizer']); ?></p>
            <a href="event.php" class="btn btn-secondary">Kembali ke Daftar Event</a>
        <?php else: ?>
            <!-- Tampilkan Daftar Event -->
            <h1 class="mb-4">Daftar Event</h1>
            <div class="row">
                <?php if (!empty($events)) : ?>
                    <?php foreach ($events as $event): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title"><?= htmlspecialchars($event['title']); ?></h5>
                                    <p class="card-text">
                                        <?= htmlspecialchars($event['date']); ?><br>
                                        <?= htmlspecialchars($event['location']); ?>
                                    </p>
                                    <a href="event.php?id=<?= $event['id']; ?>" class="btn btn-primary">
                                        Lihat Detail
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-center">Tidak ada event tersedia.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
<?php include 'footer.php'; ?>
</body>
</html>
