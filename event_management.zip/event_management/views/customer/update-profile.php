<?php
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['user_email'])) {
    header('Location: login.php');
    exit;
}

$user_email = $_SESSION['user_email'];
$pdo = new PDO('mysql:host=localhost;dbname=your_database', 'username', 'password');

// Prepare and execute update query
$full_name = $_POST['full_name'];
$email = $_POST['email'];  // Email tidak boleh diubah
$phone = $_POST['phone'];
$country = $_POST['country'];
$state = $_POST['state'];
$city = $_POST['city'];

// Upload file jika ada
if ($_FILES['profile_picture']['name']) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
    move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file);
    $profile_picture = basename($_FILES["profile_picture"]["name"]);
} else {
    $profile_picture = null;  // Gunakan gambar default jika tidak ada upload
}

// Update query
$stmt = $pdo->prepare("UPDATE users SET full_name = ?, phone = ?, country = ?, state = ?, city = ?, profile_picture = ? WHERE email = ?");
$stmt->execute([$full_name, $phone, $country, $state, $city, $profile_picture, $user_email]);

header('Location: edit-profile.php');
exit;
?>
