<?php
// Include the database connection (Make sure the path is correct)
echo realpath('config/db.php');

// Function to initialize the database connection
function getDbConnection() {
    try {
        // Assuming your 'db.php' initializes $pdo like this:
        return new PDO('mysql:host=localhost;dbname=your_database_name', 'username', 'password');
    } catch (PDOException $e) {
        error_log("Database connection failed: " . $e->getMessage());
        return null;
    }
}

// Define the function to update booking status
function updateBookingStatus() {
    $pdo = getDbConnection(); // Get the DB connection here

    if ($pdo === null) {
        error_log("Database connection is null.");
        return false; // If the connection fails, return false
    }

    try {
        // Fetch bookings with status "pending"
        $stmt = $pdo->query("SELECT * FROM bookings WHERE status = 'pending'");
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($bookings)) {
            error_log("No pending bookings found.");
        }

        foreach ($bookings as $booking) {
            $bookingId = $booking['booking_id'];
            $bookingDate = new DateTime($booking['booking_date']);
            $currentDate = new DateTime();

            // If booking is older than 1 day, change status to "confirmed"
            if ($currentDate->diff($bookingDate)->days >= 1) {
                $updateStmt = $pdo->prepare("UPDATE bookings SET status = 'confirmed' WHERE booking_id = :booking_id");
                $updateStmt->execute([':booking_id' => $bookingId]);

                if ($updateStmt->rowCount() > 0) {
                    error_log("Booking ID {$bookingId} updated to confirmed.");
                } else {
                    error_log("Failed to update Booking ID {$bookingId}.");
                }
            }
        }

        return true; // Update successful
    } catch (Exception $e) {
        error_log("Error updating booking status: " . $e->getMessage());
        return false; // Update failed
    }
}

// Call the updateBookingStatus function to update booking status
if (updateBookingStatus()) {
    echo "Booking status updated successfully.";
} else {
    echo "Failed to update booking status.";
}

// Function to get bookings from database
function getBookings() {
    $pdo = getDbConnection(); // Get the DB connection here

    if ($pdo === null) {
        return []; // Return an empty array if the connection fails
    }

    try {
        $stmt = $pdo->query("SELECT * FROM bookings");
        return $stmt->fetchAll(PDO::FETCH_ASSOC); // Return bookings
    } catch (Exception $e) {
        error_log("Error fetching bookings: " . $e->getMessage());
        return []; // Return empty array on failure
    }
}

// Fetch bookings to display in the table
$bookings = getBookings();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Booking</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .confirmed {
            color: green;
        }
        .canceled {
            color: red;
        }
        .pending {
            color: orange;
        }
    </style>
</head>
<body>
            <!-- Include Sidebar -->
            <?php include('sidebar.php'); ?>
    <h1>My Booking</h1>
    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Event</th>
                <th>Tgl Pemesanan</th>
                <th>Booking ID</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($bookings)): ?>
                <?php foreach ($bookings as $index => $booking): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= htmlspecialchars($booking['event_name'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($booking['booking_date'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($booking['booking_id'] ?? 'N/A') ?></td>
                        <td class="<?= htmlspecialchars($booking['status'] ?? 'pending') ?>">
                            <?= htmlspecialchars(ucfirst($booking['status'] ?? 'Pending')) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">Tidak ada data pemesanan.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
