if (!isset($_SESSION['user_email'])) {
    // Jika belum login, redirect ke halaman login
    header('Location:views/login.php');
    exit;
}



event detail 2
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($event['name']) ?></title>
  <style>
    /* (CSS sama seperti sebelumnya) */
  </style>
</head>
<body>
  <div class="container">
    <!-- Main Content -->
    <div class="main">
      <h1><?= htmlspecialchars($event['name']) ?></h1>
      <p><?= htmlspecialchars($event['description']) ?></p>
      <h3>Details</h3>
      <p><?= date('d F Y', strtotime($event['date'])) ?> at <?= $event['time'] ?></p>
      <p><?= htmlspecialchars($event['location']) ?></p>
    </div>

    <!-- Sidebar -->
    <div class="sidebar">
      <div class="countdown">
        <span id="days">0</span>d : <span id="hours">0</span>h : <span id="minutes">0</span>m : <span id="seconds">0</span>s
      </div>

      <div class="ticket">
        <h3>Tickets</h3>
        <?php foreach ($tickets as $ticket): ?>
        <div class="ticket-price">
          <span><?= htmlspecialchars($ticket['ticket_type']) ?></span>
          <span>Rp <?= number_format($ticket['price'], 0, ',', '.') ?></span>
          <div class="counter">
            <button onclick="decreaseCount('ticket-<?= $ticket['id'] ?>')">-</button>
            <span id="ticket-<?= $ticket['id'] ?>-count">0</span>
            <button onclick="increaseCount('ticket-<?= $ticket['id'] ?>', <?= $ticket['price'] ?>)">+</button>
          </div>
        </div>
        <?php endforeach; ?>
        <h4>Total: Rp <span id="total-price">0</span></h4>
        <a href="customer/checkout.php" class="btn">Checkout</a>
      </div>

      <h3>Location</h3>
      <a href="<?= htmlspecialchars($event['gmaps_link']) ?>" target="_blank" class="btn">View on Google Maps</a>
    </div>
  </div>

  <script>
    // (JavaScript countdown dan ticket counter sama seperti sebelumnya)
  </script>
</body>
</html>