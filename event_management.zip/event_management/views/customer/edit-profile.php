<?php
session_start();
echo realpath('config/db.php');

$user_email = $_SESSION['user_email'];

$_SESSION['user_email'] = $email_from_login; // Pastikan ini sesuai dengan hasil login Anda

// Fetch data pengguna dari database
// Koneksi ke database
$pdo = new PDO('mysql:host=localhost;dbname=event_management', 'root', ''); // Misal: root tanpa password
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$user_email]);
$user = $stmt->fetch();

// Ambil daftar negara (optional jika ingin menggunakan data dari API atau database)
$countries = ["Indonesia", "USA", "UK"]; // Contoh, bisa diambil dari database atau API
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <style>
        .main-content {
            margin-left: 270px; /* Tambahkan jarak sesuai lebar sidebar */
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-group button:hover {
            background-color: #0056b3;
        }

        .profile-picture img {
            display: block;
            margin-bottom: 10px;
            border-radius: 50%;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        .action-links {
            margin-top: 20px;
        }

        .action-links a {
            display: inline-block;
            margin-right: 15px;
            color: #007bff;
            text-decoration: none;
            font-size: 14px;
        }

        .action-links a:hover {
            text-decoration: underline;
        }
                select {
            max-width: 100%;
            overflow: auto;
        }

    </style>
<body>

<!-- Sidebar -->
<?php include('sidebar.php'); ?>

<!-- Main Content -->
<div class="main-content">
    <h1>Edit Profile</h1>
    <form action="update-profile.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="profile_picture">Profile Picture</label>
            <input type="file" id="profile_picture" name="profile_picture">
            <div class="profile-picture">
                <!-- Display current profile picture if available -->
                <img src="uploads/<?= $user['profile_picture'] ?? 'default.jpg'; ?>" alt="Profile Picture" width="100">
            </div>
            <i class="fa fa-pencil" onclick="document.getElementById('profile_picture').click();"></i>
        </div>

        <div class="form-group">
            <label for="full_name">Nama Lengkap</label>
            <input type="text" id="full_name" name="full_name" value="<?= $user['full_name']; ?>" required>
        </div>

        <div class="form-group">
            <label for="email">Alamat Email</label>
            <input type="email" id="email" name="email" value="<?= $user['email']; ?>" readonly>
        </div>

        <div class="form-group">
            <label for="phone">Handphone</label>
            <input type="text" id="phone" name="phone" placeholder="Phone ex: 08..." value="<?= $user['phone']; ?>" required>
        </div>

        <div class="form-group">
            <label for="country">Negara</label>
            <select id="country" name="country" required>
                <?php foreach ($countries as $country): ?>
                    <option value="<?= $country; ?>" <?= $user['country'] === $country ? 'selected' : ''; ?>><?= $country; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="state">Bagian</label>
            <select id="state" name="state" required>
                <!-- Provinces will be populated based on the selected country -->
            </select>
        </div>

        <div class="form-group">
            <label for="city">Kota</label>
            <select id="city" name="city" required>
                <!-- Cities will be populated based on the selected province -->
            </select>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
    </form>

    <div class="action-links">
        <a href="change-password.php" class="change-password">
            <i class="fa fa-lock"></i> Change Password
        </a>
        <a href="#" class="logout">
            <i class="fa fa-sign-out"></i> Log Out
        </a>
    </div>
</div>

<script>
    // Handle country change to populate provinces
    $('#country').on('change', function() {
        const country = $(this).val();
        // Fetch provinces based on country
        // You can replace this with a call to an API or database to fetch provinces
        const provinces = {
            "Indonesia": ["Jakarta", "Bali", "Yogyakarta"],
            "USA": ["California", "New York", "Texas"],
            "UK": ["England", "Scotland", "Wales"]
        };
        const cities = {
            "Jakarta": ["Central Jakarta", "West Jakarta"],
            "California": ["Los Angeles", "San Francisco"]
        };

        // Populate provinces
        $('#state').empty();
        provinces[country].forEach(function(state) {
            $('#state').append(`<option value="${state}">${state}</option>`);
        });

        // Populate cities based on the selected province
        $('#state').on('change', function() {
            const state = $(this).val();
            $('#city').empty();
            cities[state]?.forEach(function(city) {
                $('#city').append(`<option value="${city}">${city}</option>`);
            });
        });
    });

    // Trigger change on country load to populate provinces initially
    $('#country').trigger('change');
</script>
</body>
</html>
