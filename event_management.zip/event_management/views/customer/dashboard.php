<?php
session_start();

// Ambil data dari session
$user_email = $_SESSION['user_email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Include jQuery and DataTables CSS/JS -->

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="style.css">

    <style>
        /* Gaya untuk konten utama */
        .main-content {
            margin-left: 260px; /* Menjaga jarak dari sidebar */
            padding: 20px;
            box-sizing: border-box;
        }

        .email-box {
            border: 2px solid #007bff; /* Border biru */
            padding: 10px;
            border-radius: 5px; /* Sudut border membulat */
            background-color: #f0f8ff; /* Warna latar belakang yang cerah */
            display: inline-block; /* Agar tidak memakan seluruh lebar */
        }

         /* Gaya tambahan untuk tombol */
         #scanCardBtn {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        #scanCardBtn:hover {
            background-color: #0056b3;
        }

        /* CSS untuk membungkus Informasi Akun dan Pemesanan Terbaru dengan border */
        .section-box {
            border: 2px solid #007bff; /* Garis biru */
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .section-box h2, .section-box p {
            margin: 0 0 10px 0;
        }

        /* Gaya untuk tabel DataTables */
        #orderTable_wrapper {
            border: 2px solid #007bff; /* Garis biru pada tabel */
            border-radius: 5px;
            padding: 15px;
        }

        /* Gaya tombol */
        #scanCardBtn {
            margin-top: 10px;
        }
    </style>
</head>
<body>
            <!-- Include Sidebar -->
    <?php include('sidebar.php'); ?>

    <!-- Bagian Informasi Akun -->
    <div class="main-content">
    <div class="section-box">
        <h1>Informasi Akun</h1>
        <p><strong>Pengguna</strong></p>
        <!-- Email otomatis diambil dari session -->
       <p>Email: <span id="userEmail" class="email-box"><?= $_SESSION['user_email'] ?? 'guest@example.com' ?></span></p>
        <!-- Tombol Scan Card -->
        <button id="scanCardBtn" class="btn btn-primary">Scan Card</button>
    </div>

    <!-- Bagian Pemesanan Terbaru -->
    <div class="section-box">
        <h2>Pemesanan Terbaru</h2>
        <table id="orderTable" class="display">
            <thead>
                <tr>
                    <th>Event</th>
                    <th>Tgl Pemesanan</th>
                    <th>Tgl Event</th>
                </tr>
            </thead>
        <tbody>
            <!-- Data akan dimasukkan via AJAX -->
        </tbody>
    </table>

    <script>
        $(document).ready(function() {
            const userEmail = $('#userEmail').text(); // Ambil email dari tampilan

            $('#scanCardBtn').on('click', function() {
                window.location.href = 'customer/card-qr';
            });

            $('#orderTable').DataTable({
                ajax: {
                    url: 'api/get_orders.php',
                    type: 'GET',
                    data: { email: userEmail }, // Kirim email sebagai parameter
                    dataSrc: ''
                },
                columns: [
                    { data: 'event_name' },
                    { data: 'booking_date' },
                    { data: 'event_date' }
                ],
                language: {
                    emptyTable: "No data available in table",
                    info: "Showing _START_ to _END_ of _TOTAL_ entries",
                    infoEmpty: "Showing 0 to 0 of 0 entries",
                    search: "Search:",
                    lengthMenu: "Show _MENU_ entries",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "Next",
                        previous: "Previous"
                    }
                },
                pageLength: 10, // Jumlah default entri per halaman
                lengthMenu: [5, 10, 25, 50] // Opsi jumlah entri per halaman
            });
        });
    </script>
</body>
</html>
