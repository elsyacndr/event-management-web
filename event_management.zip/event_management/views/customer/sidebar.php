<style>
.sidebar {
            height: 100%; /* Membuat sidebar sepanjang tinggi layar */
            width: 250px; /* Lebar sidebar */
            position: fixed; /* Tetap di kiri layar */
            top: 0;
            left: 0;
            background-color: #111; /* Warna latar belakang sidebar */
            padding-top: 20px;
            color: white;
            box-sizing: border-box; /* Untuk menghitung padding dan border */
            border-right: 2px solid #ddd; /* Membuat garis pemisah dengan konten utama */
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 8px;
            text-align: center;
        }

        .sidebar ul li a {
            text-decoration: none;
            color: white;
            display: block;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        .sidebar ul li a:hover {
            background-color: #575757;
        }
</style>
<!-- sidebar.php -->
<div class="sidebar">
    <h2>Dashboard</h2>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="my-bookings.php">Bookings</a></li>
        <li><a href="my_installment.php">Cicilan</a></li>
        <li><a href="support-ticket.php">Help</a></li>
        <li><a href="edit-profile.php">Profile</a></li>
    </ul>
</div>
