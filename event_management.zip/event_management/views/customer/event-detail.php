<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'event_management');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get event details
$event_id = 1; // ID event yang diambil, sesuaikan sesuai kebutuhan
$event_query = $conn->query("SELECT * FROM events WHERE id = $event_id");
$event = $event_query->fetch_assoc();

// Get ticket details
$tickets_query = $conn->query("SELECT * FROM tickets WHERE event_id = $event_id");
$tickets = [];
while ($ticket = $tickets_query->fetch_assoc()) {
    $tickets[] = $ticket;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Event Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
    }
    .container {
      display: flex;
      justify-content: space-between;
      padding: 20px;
      box-sizing: border-box;
    }
    #musicIndoorBtn {
      margin-top: 10px;
      padding: 10px 20px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    #musicIndoorBtn:hover {
      background-color: rgb(211, 142, 31);
    }
    .image-container {
      max-width: 50%;
      margin: 0 auto;
    }

    .image-container img {
      display: block;
      width: 100%;
      height: auto;
      border-radius: 10px;
    }
    .main {
      width: 60%;
      box-sizing: border-box;
    }
    .sidebar {
      width: 35%;
      height: 100vh;
      padding: 20px;
      border-left: 1px solid #ccc;
      background-color: #f4f4f4;
      box-sizing: border-box;
    }
    .ticket {
      background-color: #fff;
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    .ticket h3 {
      margin-bottom: 10px;
      font-size: 1.5em;
    }
    .ticket-price {
      display: flex;
      justify-content: space-between;
      margin-bottom: 10px;
    }
    .counter {
      display: flex;
      align-items: center;
    }
    .counter button {
      margin: 0 10px;
      padding: 5px 10px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    .counter button:hover {
      background-color: rgb(211, 142, 31);
    }
    .countdown {
      font-size: 20px;
      margin-bottom: 20px;
    }
    .btn {
      padding: 10px 20px;
      background-color: #007bff;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      text-align: center;
      display: block;
      margin-top: 10px;
    }
    .btn:hover {
      background-color: #0056b3;
    }
    .box {
      background-color: rgb(198, 29, 108); /* Warna latar kotak */
      color: white; /* Warna teks */
      padding: 1px;
      border-radius: 10px;
      text-align: center;
      font-size: 18px;
      margin-bottom: 10px;
    }
    .box:hover {
      background-color: rgb(152, 0, 179); /* Efek hover */
    }
    .details {
      display: flex;
      flex-direction: column;
      gap: 10px;
      box-sizing: border-box;
    }
    .details .box {
      width: 100%;
    }
  </style>
</head>
<body>
  <!-- Tombol baru untuk Music Indoor Seating -->
  <button id="musicIndoorBtn">Music - Indoor Seating</button>
  <div class="image-container">
    <a href="https://freeimage.host/i/2NpPJnt" target="_blank">
      <img src="https://iili.io/2NpPJnt.md.webp" alt="Music Event">
    </a>
  </div>

  <div class="container">
    <!-- Main Content -->
    <div class="main">
      <h1>Soul Intimate Concert 4.0</h1>
      <p>Concert Experience Full of Romance For You and Your Loved Ones</p>
      <h3>Confirmed Artists</h3>
      <ul>
        <li>Ruth Sahanaya</li>
        <li>Sammy Simorangkir</li>
        <li>Soon To Be Announced...</li>
      </ul>
      <div class="details">
        <div class="box">Deskripsi</div>
        <div class="box">Lokasi</div>
        <div class="box">Talent</div>
        <div class="box">Fasilitas</div>
        <div class="box">Refund Policy</div>
      </div>
    </div>

    <div class="sidebar">
      <p>12 April 2025</p>
      <p>The Kasablanka Hall, Jakarta</p>
      <h3>Location</h3>
      <a href="https://goo.gl/maps/xyz123" target="_blank" class="btn">View on Google Maps</a>

      <h3>Share Event</h3>
      <div class="social-buttons">
        <a href="#"><img src="facebook-icon.png" alt="Facebook"></a>
        <a href="#"><img src="twitter-icon.png" alt="Twitter"></a>
        <a href="#"><img src="whatsapp-icon.png" alt="WhatsApp"></a>
        <a href="#"><img src="qr-icon.png" alt="QR Code"></a>
      </div>

      <div class="ticket">
        <h3>Tickets</h3>
        <div class="ticket-price">
          <span>Regular</span>
          <span>Rp 1.500.000</span>
          <div class="counter">
            <button onclick="decreaseCount('regular')">-</button>
            <span id="regular-count">0</span>
            <button onclick="increaseCount('regular', 1500000)">+</button>
          </div>
        </div>
        <div class="ticket-price">
          <span>VIP</span>
          <span>Rp 2.500.000</span>
          <div class="counter">
            <button onclick="decreaseCount('vip')">-</button>
            <span id="vip-count">0</span>
            <button onclick="increaseCount('vip', 2500000)">+</button>
          </div>
        </div>
        <h4>Total: Rp <span id="total-price">0</span></h4>
        <a href="customer/checkout.php" class="btn">Checkout</a>
      </div>
    </div>
  </div>

  <script>
    // Tambahkan event listener untuk tombol baru
    document.getElementById('musicIndoorBtn').addEventListener('click', function() {
      // Arahkan ke halaman events?category=music---indoor-seating
      window.location.href = 'events?category=music---indoor-seating';
    });

    // Countdown Timer
    const eventDate = new Date('April 12, 2025 17:00:00').getTime();

    function updateCountdown() {
      const now = new Date().getTime();
      const distance = eventDate - now;

      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      document.getElementById('days').innerText = days;
      document.getElementById('hours').innerText = hours;
      document.getElementById('minutes').innerText = minutes;
      document.getElementById('seconds').innerText = seconds;

      if (distance < 0) {
        clearInterval(timerInterval);
        document.querySelector('.countdown').innerText = 'Event has started!';
      }
    }

    const timerInterval = setInterval(updateCountdown, 1000);

    // Update price on ticket selection
    let regularCount = 0;
    let vipCount = 0;

    function increaseCount(type, price) {
      if (type === 'regular') {
        regularCount++;
        document.getElementById('regular-count').innerText = regularCount;
      } else if (type === 'vip') {
        vipCount++;
        document.getElementById('vip-count').innerText = vipCount;
      }
      updateTotalPrice(price);
    }

    function decreaseCount(type) {
      if (type === 'regular' && regularCount > 0) {
        regularCount--;
        document.getElementById('regular-count').innerText = regularCount;
      } else if (type === 'vip' && vipCount > 0) {
        vipCount--;
        document.getElementById('vip-count').innerText = vipCount;
      }
      updateTotalPrice();
    }

    function updateTotalPrice(price = 0) {
      const regularPrice = regularCount * 1500000;
      const vipPrice = vipCount * 2500000;
      const totalPrice = regularPrice + vipPrice;
      document.getElementById('total-price').innerText = totalPrice;
    }
  </script>
</body>
</html>
