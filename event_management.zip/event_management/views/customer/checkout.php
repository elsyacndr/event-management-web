<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Soul Intimate Concert 4.0</title>
    <style>
        /* Tambahkan gaya CSS yang telah diberikan sebelumnya */
    </style>
</head>
<body>

<div class="container">
    <h1>Checkout - Soul Intimate Concert 4.0</h1>
    
    <!-- Detail Event -->
    <div class="event-details">
        <img src="" id="event-image" alt="Soul Intimate Concert">
        <h2 id="event-name">Loading...</h2>
        <p><strong>Tanggal:</strong> <span id="event-date">Loading...</span></p>
        <p><strong>Lokasi:</strong> <span id="event-location">Loading...</span></p>
        <p><strong>Harga Tiket:</strong> <span id="event-price">Loading...</span></p>
    </div>

    <!-- Checkout Form -->
    <div class="checkout-form">
        <h3>Data Diri Pemesan</h3>
        <form id="checkout-form">
            <div class="alert">
                <strong>Perhatian!</strong><br>
                Pastikan mengisi email dengan benar.<br>
                Pastikan inbox email tidak penuh.<br>
                Download E-ticket via Email atau login ke akun Pocketsid.
            </div>

            <label for="email">Valid Email *</label>
            <input type="email" id="email" name="email" required placeholder="Masukkan Email Anda">

            <label for="name">Nama Lengkap *</label>
            <input type="text" id="name" name="name" required placeholder="Masukkan Nama Lengkap Anda">

            <label for="phone">Nomor Telepon *</label>
            <input type="text" id="phone" name="phone" required placeholder="Masukkan Nomor Telepon Anda">

            <button type="submit">Checkout</button>
        </form>
    </div>
</div>

<script>
    // Ambil data event dengan AJAX
    fetch('api/event.php')
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                alert(data.message);
            } else {
                // Menampilkan detail event ke halaman
                document.getElementById('event-image').src = data.image_url;
                document.getElementById('event-name').textContent = data.name;
                document.getElementById('event-date').textContent = data.date;
                document.getElementById('event-location').textContent = data.location;
                document.getElementById('event-price').textContent = data.price;
            }
        });

    // Proses checkout dengan AJAX
    // assets/js/script.js

document.getElementById('checkout-form').addEventListener('submit', function(e) {
    e.preventDefault();

    let formData = {
        email: document.getElementById('email').value,
        name: document.getElementById('name').value,
        phone: document.getElementById('phone').value
    };

    fetch('http://localhost/api/checkout.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
    })
    .catch(error => {
        console.error('Error:', error);
    });
});

</script>

</body>
</html>
