<?php
session_start();
echo realpath('config/db.php');

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validasi input kosong
    if (empty($email) || empty($password)) {
        $error_message = 'Email dan password tidak boleh kosong.';
    } else {
        // Query untuk memeriksa email dan password
        $query = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();

        // Query untuk insert data pengguna
        $query = "INSERT INTO users (email, password) VALUES (?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('ss', $email, $password_hashed);  // Bind parameter email dan password
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "Registrasi berhasil!";
        } else {
            echo "Terjadi kesalahan dalam registrasi.";
        }

            // Verifikasi kata sandi
            if (password_verify($password, $user['password'])) {
                // Login berhasil, simpan ke session
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_name'] = $user['name']; // Contoh: jika ada field nama

                // Redirect ke dashboard
                header('Location: dashboard.php');
                exit;
            } else {
                $error_message = 'Kata sandi salah.';
            }
        } else {
            $error_message = 'Email tidak ditemukan.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Eventhub </title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center vh-100">
            <div class="col-md-4 col-lg-3">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h3 class="text-center mb-4">Login</h3>

                        <!-- Tampilkan pesan error jika ada -->
                        <?php if (!empty($error_message)): ?>
                            <div class="alert alert-danger"><?php echo $error_message; ?></div>
                        <?php endif; ?>

                        <form method="POST" action="login.php">
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" placeholder="Email" required>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="password" placeholder="Kata Sandi (Minimal 8 karakter)" required>
                            </div> 
                            <a href="customer/dashboard.php" button type="submit" class="btn btn-primary btn-block">Login</button>
                        </form>

                        <div class="mt-3 text-center">
                            <a href="forgot_password.php">Lupa Kata Sandi?</a>
                        </div>
                        <hr>
                        <div class="text-center">
                            Tidak ada akun? <a href="register.php">Daftar Sekarang</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
