<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pembelian</title>
</head>
<body>
    <h1>Riwayat Pembelian Anda</h1>
    <input type="email" id="customerEmail" placeholder="Masukkan email Anda">
    <button onclick="loadHistory()">Lihat Riwayat</button>

    <div id="historyList"></div>

    <script>
        function loadHistory() {
            const email = document.getElementById("customerEmail").value;

            if (email) {
                fetch(`api/transactions.php?email=${email}`)
                    .then(response => response.json())
                    .then(data => {
                        let output = "<h3>Daftar Event yang Anda Beli:</h3>";
                        if (data.length > 0) {
                            data.forEach(transaction => {
                                output += `
                                    <div>
                                        <p><strong>Event:</strong> ${transaction.title}</p>
                                        <p><strong>Tanggal:</strong> ${transaction.date} ${transaction.time}</p>
                                        <p><strong>Lokasi:</strong> ${transaction.location}</p>
                                        <p><strong>Tanggal Pembelian:</strong> ${transaction.purchase_date}</p>
                                    </div>
                                    <hr>
                                `;
                            });
                        } else {
                            output += "<p>Belum ada riwayat pembelian.</p>";
                        }
                        document.getElementById("historyList").innerHTML = output;
                    })
                    .catch(error => console.error("Error:", error));
            } else {
                alert("Masukkan email terlebih dahulu!");
            }
        }
    </script>
</body>
</html>
