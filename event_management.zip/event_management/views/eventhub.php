<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management</title>
</head>
<body>
    <h1>Event Tersedia</h1>
    <div id="eventList"></div>

    <script>
        fetch("api/read.php")
            .then(response => response.json())
            .then(data => {
                let output = "";
                data.forEach(event => {
                    output += `
                        <div>
                            <h3>${event.title}</h3>
                            <p>${event.date} ${event.time}</p>
                            <p>Lokasi: ${event.location}</p>
                            <p>Organizer: ${event.organizer}</p>
                            <p>Harga: ${event.price}</p>
                            <img src="${event.image}" width="200">
                            <br>
                            <button onclick="buyEvent(${event.id})">Beli Tiket</button>
                        </div>
                        <hr>
                    `;
                });
                document.getElementById("eventList").innerHTML = output;
            })
            .catch(error => console.error("Error:", error));

        function buyEvent(eventId) {
            const customerName = prompt("Masukkan Nama Anda:");
            const customerEmail = prompt("Masukkan Email Anda:");

            if (customerName && customerEmail) {
                fetch("api/purchase.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        event_id: eventId,
                        customer_name: customerName,
                        customer_email: customerEmail
                    })
                })
                .then(response => response.json())
                .then(data => alert(data.message || data.error))
                .catch(error => console.error("Error:", error));
            } else {
                alert("Nama dan email harus diisi!");
            }
        }
    </script>
</body>
</html>





<?php include('header.php'); ?>
<?php
$imagePath = "uploads/cover.jpg"; // Path gambar
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cover Image</title>
    <style>
        .cover-container {
            width: 90%;
            height: 300px;
            border-radius: 15px;
            overflow: hidden;
            margin: 0 auto;
            background-color: #f0f0f0;
        }

        .cover-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="cover-container">
        <img src="images/event-image.jpg" alt="Deskripsi Gambar">
    </div>
</body>
</html>
<!-- Hero Section dan Event Cards -->
<section class="container mt-5">
    <h2 class="text-center mb-4">Upcoming Events</h2>
    <div class="row">
        <!-- Event 1 -->
        <div class="col-md-4">
            <div class="card event-card">
                <img src="images/event1.jpg" alt="Event 1">
                <div class="card-body">
                    <h5 class="card-title">Event Title 1</h5>
                    <p class="card-text">Date: 25 Dec 2024</p>
                    <p class="card-text">Location: New York</p>
                    <a href="customer/event-detail.php" class="btn btn-primary">View Details</a>
                </div>
            </div>
        </div>
        <!-- Event 2 -->
        <div class="col-md-4">
            <div class="card event-card">
                <img src="images/event2.jpg" alt="Event 2">
                <div class="card-body">
                    <h5 class="card-title">Event Title 2</h5>
                    <p class="card-text">Date: 30 Dec 2024</p>
                    <p class="card-text">Location: Los Angeles</p>
                    <a href="customer/event-detail.php" class="btn btn-primary">View Details</a>
                </div>
            </div>
        </div>
        <!-- Event 3 -->
        <div class="col-md-4">
            <div class="card event-card">
                <img src="images/event3.jpg" alt="Event 3">
                <div class="card-body">
                    <h5 class="card-title">Event Title 3</h5>
                    <p class="card-text">Date: 1 Jan 2025</p>
                    <p class="card-text">Location: San Francisco</p>
                    <a href="customer/event-detail.php" class="btn btn-primary">View Details</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Tambahkan di akhir halaman sebelum penutup </body> -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.4.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<!-- Hero Section - Carousel Gambar -->
<section class="container mt-5">
    <h2 class="text-center mb-4">Upcoming Events</h2>

    <!-- Bootstrap Carousel -->
    <div id="eventCarousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <!-- Gambar 1 -->
            <div class="carousel-item active">
                <img src="images/event1.jpg" class="d-block w-100" alt="Event 1">
            </div>
            <!-- Gambar 2 -->
            <div class="carousel-item">
                <img src="images/event2.jpg" class="d-block w-100" alt="Event 2">
            </div>
            <!-- Gambar 3 -->
            <div class="carousel-item">
                <img src="images/event3.jpg" class="d-block w-100" alt="Event 3">
            </div>
        </div>

        <!-- Kontrol Carousel -->
        <a class="carousel-control-prev" href="#eventCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#eventCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</section>

<?php include('footer.php'); ?>

