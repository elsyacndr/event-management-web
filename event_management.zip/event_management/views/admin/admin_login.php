<!-- admin_login.php -->
<form method="POST" action="authController.php">
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>

    <button type="submit">Login as Admin</button>
</form>
