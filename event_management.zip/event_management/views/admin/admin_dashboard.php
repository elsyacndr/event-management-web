<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        form { margin-bottom: 20px; }
    </style>
</head>
<body>
    <h1>Dashboard Admin</h1>

    <!-- Form Tambah Event -->
    <h2>Tambah Event</h2>
    <form onsubmit="return addEvent();">
        <label>Nama Event:</label><br>
        <input type="text" id="name" required><br>
        <label>Tanggal:</label><br>
        <input type="date" id="date" required><br>
        <label>Harga Tiket:</label><br>
        <input type="number" id="price" required><br>
        <button type="submit">Tambah Event</button>
    </form>
    
    <!-- Form Edit Event -->
    <h2>Edit Event</h2>
    <form id="editEventForm" onsubmit="return updateEvent();">
        <input type="hidden" id="editId">
        <label>Nama Event:</label><br>
        <input type="text" id="editName" required><br>
        <label>Tanggal:</label><br>
        <input type="date" id="editDate" required><br>
        <label>Harga Tiket:</label><br>
        <input type="number" id="editPrice" required><br>
        <button type="submit">Update Event</button>
        <button type="button" onclick="cancelEdit()">Batal</button>
    </form>
    <style>
    #editEventForm {
        display: none;
        margin-bottom: 20px;
    }
    </style>

    <!-- Daftar Event -->
    <h2>Daftar Event</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Event</th>
                <th>Tanggal</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody id="eventTableBody">
            <!-- Data Event akan dimuat di sini -->
        </tbody>
    </table>

    <script>
        // Fetch data event dari API
        function loadEvents() {
            fetch('api/get_events.php')
                .then(response => response.json())
                .then(data => {
                    const tableBody = document.getElementById('eventTableBody');
                    tableBody.innerHTML = '';
                    data.forEach(event => {
                        tableBody.innerHTML += `
                            <tr>
                                <td>${event.id}</td>
                                <td>${event.name}</td>
                                <td>${event.date}</td>
                                <td>${event.price}</td>
                                <td>
                                    <button onclick="editEvent(${event.id}, '${event.name}', '${event.date}', ${event.price})">Edit</button>
                                    <button onclick="deleteEvent(${event.id})">Hapus</button>
                                </td>
                            </tr>
                        `;
                    });
                });
        }

        // Tambah Event melalui API
        function addEvent() {
            const name = document.getElementById('name').value;
            const date = document.getElementById('date').value;
            const price = document.getElementById('price').value;

            fetch('api/add_event.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, date, price })
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.status === 'success') {
                    loadEvents();
                }
            });
            return false;
        }

        //Fungsi Edit Event
        function editEvent(id, name, date, price) {
            document.getElementById('editId').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('editDate').value = date;
            document.getElementById('editPrice').value = price;
            document.getElementById('editEventForm').style.display = 'block';
        }

        //Edit Event melalui API
        function updateEvent() {
            const id = document.getElementById('editId').value;
            const name = document.getElementById('editName').value;
            const date = document.getElementById('editDate').value;
            const price = document.getElementById('editPrice').value;

            fetch('api/edit_event.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, name, date, price })
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.status === 'success') {
                    loadEvents(); // Reload event list
                    cancelEdit(); // Hide form edit
                }
            });
            return false;
        }

        function cancelEdit() {
            document.getElementById('editEventForm').style.display = 'none';
        }


        // Hapus Event melalui API
        function deleteEvent(id) {
            if (confirm("Apakah Anda yakin ingin menghapus event ini?")) {
                fetch('api/delete_event.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    if (data.status === 'success') {
                        loadEvents();
                    }
                });
            }
        }

        // Load event saat halaman dimuat
        loadEvents();
    </script>
    
</body>
</html>

