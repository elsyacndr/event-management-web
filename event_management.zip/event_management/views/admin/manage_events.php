<form method="POST" action="">
    Judul Event: <input type="text" name="title" required>
    Deskripsi: <textarea name="description" required></textarea>
    Tanggal Event: <input type="date" name="event_date" required>
    <button type="submit">Tambah Event</button>
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $event_date = $_POST['event_date'];

    $conn->query("INSERT INTO events (title, description, event_date) VALUES ('$title', '$description', '$event_date')");
    echo "Event berhasil ditambahkan!";
}
?>
