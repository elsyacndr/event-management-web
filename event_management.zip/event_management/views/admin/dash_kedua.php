<?php
include('config/db.php');

// Ambil data jumlah tiket terjual per konser
$query = "SELECT e.name AS concert_name, COUNT(r.id) AS ticket_sold 
          FROM events e 
          LEFT JOIN registrations r ON e.id = r.event_id 
          GROUP BY e.id";

$result = $pdo->query($query);

// Siapkan data untuk Chart.js
$concert_names = [];
$tickets_sold = [];

while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
    $concert_names[] = $row['concert_name'];
    $tickets_sold[] = $row['ticket_sold'];
}

?>

<canvas id="salesChart"></canvas>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Data dari PHP
    var concertNames = <?php echo json_encode($concert_names); ?>;
    var ticketsSold = <?php echo json_encode($tickets_sold); ?>;

    // Buat grafik menggunakan data dinamis
    var ctx = document.getElementById('salesChart').getContext('2d');
    var chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: concertNames,
            datasets: [{
                label: 'Jumlah Tiket Terjual',
                data: ticketsSold,
                backgroundColor: 'rgba(75, 192, 192, 0.5)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
