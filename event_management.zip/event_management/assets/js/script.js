/*!
* Start Bootstrap - Heroic Features v5.0.6 (https://startbootstrap.com/template/heroic-features)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-heroic-features/blob/master/LICENSE)
*/
// This file is intentionally blank
// Use this file to add JavaScript to your project

// Misalnya, untuk validasi form sebelum disubmit
document.querySelector("form").addEventListener("submit", function(event) {
    let email = document.querySelector("[name='email']").value;
    let password = document.querySelector("[name='password']").value;
    
    if (email == "" || password == "") {
        event.preventDefault();
        alert("Harap isi semua kolom!");
    }
});
// assets/js/script.js

document.getElementById('checkout-form').addEventListener('submit', function(e) {
    e.preventDefault();

    let formData = {
        email: document.getElementById('email').value,
        name: document.getElementById('name').value,
        phone: document.getElementById('phone').value
    };

    fetch('http://localhost/api/checkout.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
    })
    .catch(error => {
        console.error('Error:', error);
    });
});

