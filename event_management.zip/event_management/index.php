<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management</title>
</head>
<body>
    <h1>Event Tersedia</h1>
    <div id="eventList"></div>

    <script>
        fetch("api/read.php")
            .then(response => response.json())
            .then(data => {
                let output = "";
                data.forEach(event => {
                    output += `
                        <div>
                            <h3>${event.title}</h3>
                            <p>${event.date} ${event.time}</p>
                            <p>Lokasi: ${event.location}</p>
                            <p>Organizer: ${event.organizer}</p>
                            <p>Harga: ${event.price}</p>
                            <img src="${event.image}" width="200">
                            <br>
                            <button onclick="buyEvent(${event.id})">Beli Tiket</button>
                        </div>
                        <hr>
                    `;
                });
                document.getElementById("eventList").innerHTML = output;
            })
            .catch(error => console.error("Error:", error));

        function buyEvent(eventId) {
            const customerName = prompt("Masukkan Nama Anda:");
            const customerEmail = prompt("Masukkan Email Anda:");

            if (customerName && customerEmail) {
                fetch("api/purchase.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        event_id: eventId,
                        customer_name: customerName,
                        customer_email: customerEmail
                    })
                })
                .then(response => response.json())
                .then(data => alert(data.message || data.error))
                .catch(error => console.error("Error:", error));
            } else {
                alert("Nama dan email harus diisi!");
            }
        }
    </script>
</body>
</html>
