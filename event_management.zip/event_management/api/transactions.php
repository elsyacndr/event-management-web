<?php
header("Content-Type: application/json");
include 'config/db.php';

if (isset($_GET['email'])) {
    $email = $_GET['email'];
    $query = "SELECT t.id, e.title, e.date, e.time, e.location, t.purchase_date 
              FROM transactions t 
              JOIN events e ON t.event_id = e.id
              WHERE t.customer_email = '$email'";
    
    $result = $conn->query($query);
    $transactions = [];
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }

    echo json_encode($transactions);
} else {
    echo json_encode(["error" => "Email tidak ditemukan"]);
}
?>
