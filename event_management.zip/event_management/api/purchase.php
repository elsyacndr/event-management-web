<?php
header("Content-Type: application/json");
include 'config/db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['event_id'], $data['customer_name'], $data['customer_email'])) {
    $event_id = $data['event_id'];
    $customer_name = $data['customer_name'];
    $customer_email = $data['customer_email'];

    $query = "INSERT INTO transactions (event_id, customer_name, customer_email) 
              VALUES ('$event_id', '$customer_name', '$customer_email')";

    if ($conn->query($query)) {
        echo json_encode(["message" => "Pembelian berhasil"]);
    } else {
        echo json_encode(["error" => $conn->error]);
    }
} else {
    echo json_encode(["error" => "Data tidak lengkap"]);
}
?>
