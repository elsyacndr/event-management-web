<?php
header("Content-Type: application/json");
include 'config/db.php';

$data = json_decode(file_get_contents("php://input"));

if (isset($data->name) && isset($data->date) && isset($data->price)) {
    $name = $data->name;
    $date = $data->date;
    $price = $data->price;

    $query = "INSERT INTO events (name, date, price) VALUES ('$name', '$date', '$price')";
    if ($conn->query($query)) {
        echo json_encode(["status" => "success", "message" => "Event berhasil ditambahkan"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Gagal menambahkan event"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Data tidak lengkap"]);
}
?>
