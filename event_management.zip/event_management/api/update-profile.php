<?php
header('Content-Type: application/json');

// Ambil data dari input JSON
$data = json_decode(file_get_contents('php://input'), true);

// Periksa apakah data valid
if (!$data || !isset($data['email'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}

// Koneksi ke database
try {
    $pdo = new PDO('mysql:host=localhost;dbname=event_management', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}

// Validasi dan ambil data
$full_name = htmlspecialchars($data['full_name'] ?? '');
$email = filter_var($data['email'], FILTER_VALIDATE_EMAIL);
$phone = htmlspecialchars($data['phone'] ?? '');
$country = htmlspecialchars($data['country'] ?? '');
$state = htmlspecialchars($data['state'] ?? '');
$city = htmlspecialchars($data['city'] ?? '');
$profile_picture = htmlspecialchars($data['profile_picture'] ?? ''); // URL gambar atau file path

// Validasi data wajib
if (!$email || !$full_name) {
    echo json_encode(['success' => false, 'message' => 'Email and full name are required']);
    exit;
}

// Update data di database
try {
    $stmt = $pdo->prepare("UPDATE users SET full_name = ?, phone = ?, country = ?, state = ?, city = ?, profile_picture = ? WHERE email = ?");
    $result = $stmt->execute([$full_name, $phone, $country, $state, $city, $profile_picture, $email]);

    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update profile']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

exit;
?>
