<?php
header("Content-Type: application/json");
include 'config/db.php';

$data = json_decode(file_get_contents("php://input"));

if (isset($data->id)) {
    $id = $data->id;

    $query = "DELETE FROM events WHERE id = $id";
    if ($conn->query($query)) {
        echo json_encode(["status" => "success", "message" => "Event berhasil dihapus"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Gagal menghapus event"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "ID event tidak ditemukan"]);
}
?>
