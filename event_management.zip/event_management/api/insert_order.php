<?php
require_once 'config/db.php'; // Koneksi database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email']; // Email pengguna
    $eventName = $_POST['event_name']; // Nama event
    $bookingDate = date('Y-m-d'); // Tanggal pemesanan (otomatis tanggal sekarang)
    $eventDate = $_POST['event_date']; // Tanggal event

    // Query untuk memasukkan data ke tabel orders
    $query = "INSERT INTO orders (user_email, event_name, booking_date, event_date) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssss', $email, $eventName, $bookingDate, $eventDate);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Order added successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to add order"]);
    }
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
}
?>
