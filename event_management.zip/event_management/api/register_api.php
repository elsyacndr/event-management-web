<?php
session_start();

// Memeriksa jika form di-submit via AJAX (POST request)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../config/db.php'; // Pastikan koneksi database sudah di-load

    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validasi input kosong
    if (empty($name) || empty($email) || empty($password)) {
        echo json_encode(['status' => 'error', 'message' => 'Semua kolom harus diisi.']);
        exit;
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Query untuk insert data pengguna
    try {
        $query = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('sss', $name, $email, $hashed_password); // Bind parameter name, email, password
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo json_encode(['status' => 'success', 'message' => 'Registrasi berhasil!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Terjadi kesalahan dalam registrasi.']);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Kesalahan: ' . $e->getMessage()]);
    }
} else {
    // Jika bukan POST, tampilkan pesan kesalahan
    echo json_encode(['status' => 'error', 'message' => 'Metode request tidak valid.']);
}
?>
