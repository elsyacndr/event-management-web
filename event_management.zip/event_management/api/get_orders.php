<?php
session_start();
include 'config/db.php'; // Pastikan path ke file koneksi database benar

// Ambil email pengguna dari session
$user_email = $_SESSION['user_email'];

// Query untuk mengambil data pemesanan berdasarkan email pengguna
$query = "SELECT event_name, order_date, event_date FROM orders WHERE user_email = '$user_email' ORDER BY order_date DESC";
$result = mysqli_query($conn, $query);

$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

// Mengirimkan data dalam format JSON
echo json_encode(['data' => $data]);
?>
