<?php
// api/checkout.php
echo realpath('config/db.php');

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['email']) || !isset($data['name']) || !isset($data['phone'])) {
    echo json_encode(["message" => "Data tidak lengkap"]);
    exit();
}

$email = $data['email'];
$name = $data['name'];
$phone = $data['phone'];

$query = "INSERT INTO checkout (email, name, phone) VALUES (?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $email, $name, $phone);

if ($stmt->execute()) {
    echo json_encode(["message" => "Checkout berhasil, e-ticket akan dikirim ke email Anda"]);
} else {
    echo json_encode(["message" => "Checkout gagal, coba lagi"]);
}

$stmt->close();
$conn->close();
?>
