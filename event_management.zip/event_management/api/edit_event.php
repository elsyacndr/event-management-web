<?php
header("Content-Type: application/json");
include 'config/db.php';

$data = json_decode(file_get_contents("php://input"));

if (isset($data->id) && isset($data->name) && isset($data->date) && isset($data->price)) {
    $id = $data->id;
    $name = $data->name;
    $date = $data->date;
    $price = $data->price;

    $query = "UPDATE events SET name = '$name', date = '$date', price = $price WHERE id = $id";
    if ($conn->query($query)) {
        echo json_encode(["status" => "success", "message" => "Event berhasil diperbarui"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Gagal memperbarui event"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Data tidak lengkap"]);
}
?>
