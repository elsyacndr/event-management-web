<?php
echo realpath('config/db.php');

// Define the function to update booking status
function updateBookingStatus($pdo) {
    try {
        // Fetch bookings with status "pending"
        $stmt = $pdo->query("SELECT * FROM bookings WHERE status = 'pending'");
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($bookings as $booking) {
            $bookingId = $booking['booking_id'];
            $bookingDate = new DateTime($booking['booking_date']);
            $currentDate = new DateTime();

            // If booking is older than 1 day, change status to "confirmed"
            if ($currentDate->diff($bookingDate)->days >= 1) {
                $updateStmt = $pdo->prepare("UPDATE bookings SET status = 'confirmed' WHERE booking_id = :booking_id");
                $updateStmt->execute([':booking_id' => $bookingId]);
            }
        }

        return true; // Update successful
    } catch (Exception $e) {
        error_log("Error updating booking status: " . $e->getMessage());
        return false; // Update failed
    }
}

// Call the updateBookingStatus function to update booking status
if (updateBookingStatus($pdo)) {
    echo "Booking status updated successfully.";
} else {
    echo "Failed to update booking status.";
}
?>

