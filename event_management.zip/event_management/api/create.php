<?php
header("Content-Type: application/json");
include 'config/db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['title'], $data['date'], $data['time'], $data['location'], $data['organizer'], $data['price'], $data['image'])) {
    $title = $data['title'];
    $date = $data['date'];
    $time = $data['time'];
    $location = $data['location'];
    $organizer = $data['organizer'];
    $price = $data['price'];
    $image = $data['image'];

    $query = "INSERT INTO events (title, date, time, location, organizer, price, image) 
              VALUES ('$title', '$date', '$time', '$location', '$organizer', '$price', '$image')";
    
    if ($conn->query($query)) {
        echo json_encode(["message" => "Event berhasil ditambahkan"]);
    } else {
        echo json_encode(["error" => $conn->error]);
    }
} else {
    echo json_encode(["error" => "Data tidak lengkap"]);
}
?>
