function getAllEvents($pdo) {
    $stmt = $pdo->query("SELECT * FROM events");
    return $stmt->fetchAll();
}
 