<?php
$host = 'localhost'; // Host biasanya localhost
$username = 'root';  // Username default untuk XAMPP atau MAMP
$password = '';      // Password default untuk XAMPP atau MAMP kosong
$dbname = 'event_management'; // Pastikan nama database sesuai dengan yang Anda buat

// Koneksi ke database
$conn = new mysqli($host, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi ke database gagal: " . $e->getMessage());
}
?>
