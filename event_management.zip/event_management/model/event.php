<?php

class Event {
    public static function getEventById($eventId) {
        // Menggunakan koneksi database untuk mengambil event berdasarkan ID
        $conn = new mysqli("localhost", "root", "", "event_db");
        
        // Pastikan koneksi berhasil
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $query = "SELECT * FROM events WHERE id = $eventId";
        $result = $conn->query($query);
        
        if ($result->num_rows > 0) {
            return $result->fetch_assoc(); // Mengembalikan data acara dalam bentuk array
        } else {
            return null; // Jika acara tidak ditemukan
        }

        $conn->close();
    }
}
?>
